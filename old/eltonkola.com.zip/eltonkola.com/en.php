<?php
/*
PERKTHIMI NE GJUHEN ANGLEZE
VER 0.1
*/

//pjese statike te cdo faqeje, si menuja,koka e bishti
$BISHTI_RRESHTI1='&copy; 2000-2010. Elton Kola all right reserved';
$BISHTI_RRESHTI2='designing and coding my dreams since 2001';

$MENU_HOME_TIT='home';
$MENU_HOME_TXT='about me';
$MENU_WEBDESIGN_TIT='webdesign';
$MENU_WEBDESIGN_TXT='webdesign skills';
$MENU_PROGRAMMING_TIT='programming';
$MENU_PROGRAMMING_TXT='programming skills';
$MENU_PORTFOLIO_TIT='portfolio';
$MENU_PORTFOLIO_TXT='some of my works';
$MENU_KONTAKT_TIT='contact';
$MENU_KONTAKT_TXT='more informations';

$PLAY= 'play';
$PLAUSE= 'pause';


//faqja e pare, index
$INDEX_TITULLI='About Me';
$INDEX_TXT=	'My Name is Elton Kola. I am an albanian web designer and programmer .'. 
			'Actualy i am living and working in New York. <br>'.
			'This is my website where you can have more information about me and my work. <br>'. 
			' You can download my cv for more detagliated information about my past employments.';
$INDEX_LINK_OLD='Visit my blog';	
$INDEX_LINK_URL='http://www.eltonkola.com/blog/en';	
$INDEX_SOCIAL='Find me online on internet on: ';
$INDEX_FOTO='images/eltonkola_us.jpg';
$INDEX_CV_URL='doc/elton_kola_resume_en_2011.pdf';
$INDEX_DOWNLOAD_CV='Download my cv';

//faqja webdesign
$WEBDESIGN_TITULLI='Webdesign';
$WEBDESIGN_TXT=	'Web design is my passion. Projecting, creating ,re designing web pages isn\'t only my job, but '.
				'even my hobby. Html, css, javascript, jquery, dojo, php , asp are the tools and languages that i use to create'.
				'my projects.'.
				'Web page optimisation for search engines and more accessible code, and every post creation process'.
				' is my daily job.<br>'.
				'If you are interested in creating a hi impact web page, or interested in hiring me, feel free to contact me.'.
				'See portfolio page for some of my creations.<br>'.
				'Soon i thing i will open a lab page, with my experimental thinks, stay tuned..'.
				'';

			

$WEBDESIGN_FOTO='images/img_webdesign.jpg';

//faqja programin, dinamike me array...

$PROGRAMMING_TITULLI[0] = 'Programming skills';
$PROGRAMMING_TITULLI_ANASH[0] = 'Programming skills';
$PROGRAMMING_TXT[0] = 	'I love web, all what is fresh and new, and of course i love open source. Java is the '.
						'the perfect combination of these, and i have been working in java, j2ee in the last years.<br>'.
						'Languages and tools that i use are:<br> xhtml, css,flash, actionscript, javascript, jquery,'.
						'asp, php, jsp, java, j2ee, visualbasic, seo, mysql, mssql, access, oracle,
						postgresql, photoshop, fireworks etc <br>'.
						'Front-end e gui are my favorite parts.'.
						'';


$PROGRAMMING_FOTO[0] = 'images/img_programming.jpg';

$PROGRAMMING_TITULLI[1] = 'Social apps';
$PROGRAMMING_TITULLI_ANASH[1] = 'Facebook applications';
$PROGRAMMING_TXT[1] = 	'In the last years internet scenario has changed a lot from the influence of microblogging and '.
						'social networks like twitter and facebook. With the conviction that the web will be more '.
						'social in the future, i have been developing social and viral applications for facebook.<br>'.
						'I will be working on this even in the future, sure that the importance of these applications will'.
						' increase.<br> If you are interested in promoting you brand, product or have an innovative and original idea'.
						' feel free to contact me'.
						'';

$PROGRAMMING_FOTO[1] = 'images/img_facebook.jpg';

$PROGRAMMING_TITULLI[2] = 'Mobile apps';
$PROGRAMMING_TITULLI_ANASH[2] = 'Mobile applications';
$PROGRAMMING_TXT[2] = 	'The world is everyday more mobile, the presence of your application on the pocket of your consumers'.
						' is very important. In the mobile os war, i bet on android.<br>I am a registered android developer'.
						' with several applications in android market.<br> If you need an android application, or have a innovative idea'.
						' contact me, and we will project and create together the app what is missing on your device.<br>'.
				
						'To see a list of my android apps please visit this page: '.
						'<a href="http://www.androlib.com/android.developer.elton-kola-qEFF.aspx" target="_blank">androlib</a>';

						
						
$PROGRAMMING_FOTO[2] = 'images/img_android.jpg';

//faqja portfolio
$PORTFOLIO_IKONA[0]='portfolio/ikona/1.png';
$PORTFOLIO_FOTO[0]='portfolio/foto/1.png';
$PORTFOLIO_TITULLI[0]='My patente - facebook';
$PORTFOLIO_TXT[0]='Facebook application, quiz for italian driving license. - <a href="http://apps.facebook.com/mypatente" target="_blank">visit</a>';

$PORTFOLIO_IKONA[1]='portfolio/ikona/2.png';
$PORTFOLIO_FOTO[1]='portfolio/foto/2.png';
$PORTFOLIO_TITULLI[1]='Albania';
$PORTFOLIO_TXT[1]='Website project presenting Albania - status offline';

$PORTFOLIO_IKONA[2]='portfolio/ikona/3.png';
$PORTFOLIO_FOTO[2]='portfolio/foto/3.png';
$PORTFOLIO_TITULLI[2]='Travelbalkans.com';
$PORTFOLIO_TXT[2]='Albanian traveling agency booking website - status offline';

$PORTFOLIO_IKONA[3]='portfolio/ikona/4.png';
$PORTFOLIO_FOTO[3]='portfolio/foto/4.png';
$PORTFOLIO_TITULLI[3]='Filmmission.it';
$PORTFOLIO_TXT[3]='Cinematografic security company website. - <a href="http://www.filmmission.it" target="_blank">visit</a>';

$PORTFOLIO_IKONA[4]='portfolio/ikona/5.png';
$PORTFOLIO_FOTO[4]='portfolio/foto/5.png';
$PORTFOLIO_TITULLI[4]='Cta-gb.it';
$PORTFOLIO_TXT[4]='Local company website. - <a href="http://www.cta-gb.it" target="_blank">visit</a>';

$PORTFOLIO_IKONA[5]='portfolio/ikona/6.png';
$PORTFOLIO_FOTO[5]='portfolio/foto/6.png';
$PORTFOLIO_TITULLI[5]='AdnReader';
$PORTFOLIO_TXT[5]='Rss reader of albdevnet.com for android';

$PORTFOLIO_IKONA[6]='portfolio/ikona/7.png';
$PORTFOLIO_FOTO[6]='portfolio/foto/7.png';
$PORTFOLIO_TITULLI[6]='ElEdit';
$PORTFOLIO_TXT[6]='Html multitab editor for android.';

$PORTFOLIO_IKONA[7]='portfolio/ikona/8.png';
$PORTFOLIO_FOTO[7]='portfolio/foto/8.png';
$PORTFOLIO_TITULLI[7]='Mypatente - android';
$PORTFOLIO_TXT[7]='Italian licence guide quiz for android.';

$PORTFOLIO_IKONA[8]='portfolio/ikona/9.png';
$PORTFOLIO_FOTO[8]='portfolio/foto/9.png';
$PORTFOLIO_TITULLI[8]='MySmsBomber';
$PORTFOLIO_TXT[8]='Sms utility for android for sending multiple sms on android.';

$PORTFOLIO_IKONA[9]='portfolio/ikona/10.png';
$PORTFOLIO_FOTO[9]='portfolio/foto/10.png';
$PORTFOLIO_TITULLI[9]='EltonKola.com - old versione';
$PORTFOLIO_TXT[9]='Old version of this website. - <a href="http://www.eltonkola.com/old" target="_blank">visit</a>';

$PORTFOLIO_IKONA[10]='portfolio/ikona/11.png';
$PORTFOLIO_FOTO[10]='portfolio/foto/11.png';
$PORTFOLIO_TITULLI[10]='AlbDevNet.com';
$PORTFOLIO_TXT[10]='Albanian Developer Network. - <a href="http://www.albdevnet.com" target="_blank">visit</a>';

$PORTFOLIO_IKONA[11]='portfolio/ikona/12.png';
$PORTFOLIO_FOTO[11]='portfolio/foto/12.png';
$PORTFOLIO_TITULLI[11]='AlbanianBox.com';
$PORTFOLIO_TXT[11]='AlbanianBox a jukebox music player with albanian music. - <a href="http://www.albanianbox.com" target="_blank">visit</a>';



// faqja kontakt
$KONTAKT_TITULLI='Contact me';
$KONTAKT_TXT='Feel free to contact me for anything';
$KONTAKT_FOTO='images/img_contact.jpg';
$KONTAKT_EMRI='Name:';
$KONTAKT_EMAILI='Email:';
$KONTAKT_SUBJEKTI='Subejct:';
$KONTAKT_MESAZHIJUAJ='Your messagge:';
$KONTAKT_DERGO='Send';
$KONTAKT_FALEMINDERIT='A mail was send to Elton Kola, he will contact you as soon as posible!';
$KONTAKT_GABIM='There was an error, please try again!';
$KONTAKT_GABIM_EMRI='Write your name!';
$KONTAKT_GABIM_EMAILI='Write your email!';
$KONTAKT_GABIM_TXT='Write a messagge!';

?>
