<?php
//Server Address
$SmtpServer="mail.eltonkola.com";
$SmtpPort="26";//25
$SmtpUser="eltonkol";
$SmtpPass="$$ElidonaKola81$$";

?>