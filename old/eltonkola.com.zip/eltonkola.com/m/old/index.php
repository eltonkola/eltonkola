<?php
	header( "Location: http://www.eltonkola.com/old" );
	exit;
?>